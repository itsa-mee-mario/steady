# Steady (demo)

A scripted demo of a helper with two parts:
- **Your screen**: follows rules the user can read (for example, "On Sundays, show Call Anna"). It changes only when the user says so.
- **Right now**: takes the shape of each request (list, reminder, note, weather, calculator).

## Run
Open `index.html` in a browser. No build step. No server. Nothing leaves the browser.
The font loads from Google Fonts. The page works with a fallback font if offline.

## Notes
- The demo is scripted. It has no real AI.
- State lives in memory only. A reload resets it.
- The 18-step tour is the `STEPS` array in `index.html`.
- `tests/replay-tour.js` replays every tour step headless with Node.
  Run it from this folder after pointing its path to `index.html`.
